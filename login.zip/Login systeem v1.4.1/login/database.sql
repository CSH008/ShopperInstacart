DROP TABLE IF EXISTS login_bans;

CREATE TABLE `login_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_blocks;

CREATE TABLE `login_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `logs` int(11) NOT NULL,
  `reason` text NOT NULL,
  `until` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_forgot_codes;

CREATE TABLE `login_forgot_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `used` tinyint(1) NOT NULL,
  `code` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_inputs;

CREATE TABLE `login_inputs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place` int(11) NOT NULL,
  `name` text NOT NULL,
  `public_name` text NOT NULL,
  `type` text NOT NULL,
  `placeholder` text NOT NULL,
  `value` text NOT NULL,
  `required` text NOT NULL,
  `input_error` text NOT NULL,
  `maxlength` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `step` int(11) NOT NULL,
  `rows` int(11) NOT NULL,
  `checked` text NOT NULL,
  `options` text NOT NULL,
  `public` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO login_inputs VALUES('1','1','country','Your country','text','','','false','','0','0','0','0','0','false','','true');




DROP TABLE IF EXISTS login_log;

CREATE TABLE `login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `success` tinyint(1) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `uid` int(11) NOT NULL,
  `try` text NOT NULL,
  `type` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_messages;

CREATE TABLE `login_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sendfrom` int(11) NOT NULL,
  `sendto` int(11) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `time` int(11) NOT NULL,
  `opened` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_payments;

CREATE TABLE `login_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `amount` text NOT NULL,
  `currency` text NOT NULL,
  `payer` text NOT NULL,
  `receiver` text NOT NULL,
  `txn_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS login_permissions;

CREATE TABLE `login_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `level` int(11) NOT NULL,
  `on_login` text NOT NULL,
  `on_logout` text NOT NULL,
  `no_permission` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO login_permissions VALUES('1','Admin','3','/login/settings.php?page=main','','');
INSERT INTO login_permissions VALUES('2','Superuser','2','','','');
INSERT INTO login_permissions VALUES('3','User','1','','','');




DROP TABLE IF EXISTS login_settings;

CREATE TABLE `login_settings` (
  `setting` text NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO login_settings VALUES('page_disabled_message','');
INSERT INTO login_settings VALUES('timezone','');
INSERT INTO login_settings VALUES('default_permission','3');
INSERT INTO login_settings VALUES('login_with','username');
INSERT INTO login_settings VALUES('admin_email','');
INSERT INTO login_settings VALUES('email_name','admin');
INSERT INTO login_settings VALUES('online_time','5');
INSERT INTO login_settings VALUES('disable_register','false');
INSERT INTO login_settings VALUES('disable_login','false');
INSERT INTO login_settings VALUES('disable_profile','false');
INSERT INTO login_settings VALUES('public_profiles','false');
INSERT INTO login_settings VALUES('username_change','false');
INSERT INTO login_settings VALUES('email_change','false');
INSERT INTO login_settings VALUES('password_change','true');
INSERT INTO login_settings VALUES('send_messages','false');
INSERT INTO login_settings VALUES('max_failed_attempts','10');
INSERT INTO login_settings VALUES('blocked_amount','24');
INSERT INTO login_settings VALUES('blocked_format','hours');
INSERT INTO login_settings VALUES('log_successful_logins','true');
INSERT INTO login_settings VALUES('log_failed_logins','true');
INSERT INTO login_settings VALUES('redirect_last_page','false');
INSERT INTO login_settings VALUES('case_sensitive','false');
INSERT INTO login_settings VALUES('publickey','');
INSERT INTO login_settings VALUES('privatekey','');
INSERT INTO login_settings VALUES('max_ip','0');
INSERT INTO login_settings VALUES('recaptcha','false');
INSERT INTO login_settings VALUES('require_email','false');
INSERT INTO login_settings VALUES('send_welcome_mail','false');
INSERT INTO login_settings VALUES('activation','0');
INSERT INTO login_settings VALUES('username_minlength','4');
INSERT INTO login_settings VALUES('username_maxlength','16');
INSERT INTO login_settings VALUES('password_minlength','6');
INSERT INTO login_settings VALUES('password_maxlength','20');
INSERT INTO login_settings VALUES('mailtype','local');
INSERT INTO login_settings VALUES('smtp_hostname','');
INSERT INTO login_settings VALUES('smtp_username','');
INSERT INTO login_settings VALUES('smtp_password','');
INSERT INTO login_settings VALUES('smtp_port','');
INSERT INTO login_settings VALUES('smtp_ssl','false');
INSERT INTO login_settings VALUES('welcome_mail_subject','Welcome {name}');
INSERT INTO login_settings VALUES('welcome_mail','&lt;h2&gt;Welcome&lt;/h2&gt;\r\n\r\n\r\n\r\nThank you for your registration.\r\n\r\nWe hope you enjoy your time here.\r\n\r\n\r\n\r\n&lt;h2&gt;Your info&lt;/h2&gt;\r\n\r\n&lt;strong&gt;Name:&lt;/strong&gt; {name}\r\n\r\n&lt;strong&gt;Email:&lt;/strong&gt; {email}\r\n\r\n&lt;strong&gt;Registration date:&lt;/strong&gt; {date}\r\n\r\n&lt;strong&gt;IP:&lt;/strong&gt; {ip}\r\n\r\n&lt;strong&gt;Permission:&lt;/strong&gt; {perm}');
INSERT INTO login_settings VALUES('validation_mail_subject','Validation of {email}');
INSERT INTO login_settings VALUES('validation_mail','Click on the url below to activate your account:\r\n\r\n{val_url}');
INSERT INTO login_settings VALUES('reset_mail_subject','Password reset request');
INSERT INTO login_settings VALUES('reset_mail','We received your password reset request.\r\n\r\nIf you didn&#039;t do this, please ignore this email or if this happens more often try to report it to the owner of this site.\r\n\r\n\r\n\r\nClick on the url below to change your password:\r\n\r\n{reset_url}');
INSERT INTO login_settings VALUES('use_redirect_login','true');
INSERT INTO login_settings VALUES('redirect_login','/login/profile.php');
INSERT INTO login_settings VALUES('use_redirect_logout','false');
INSERT INTO login_settings VALUES('redirect_logout','');
INSERT INTO login_settings VALUES('use_redirect_nopermission','true');
INSERT INTO login_settings VALUES('redirect_nopermission','/login/login.php?m=1');
INSERT INTO login_settings VALUES('use_redirect_notloggedin','true');
INSERT INTO login_settings VALUES('redirect_notloggedin','/login/login.php?m=1');
INSERT INTO login_settings VALUES('message_login','You are logged in now');
INSERT INTO login_settings VALUES('message_logout','You are logged out now');
INSERT INTO login_settings VALUES('message_nopermission','You don&#039;t have enough permissions to do that');
INSERT INTO login_settings VALUES('message_notloggedin','You are not logged in');
INSERT INTO login_settings VALUES('social_verification','false');
INSERT INTO login_settings VALUES('social_pay','true');
INSERT INTO login_settings VALUES('enable_google','false');
INSERT INTO login_settings VALUES('client_id','');
INSERT INTO login_settings VALUES('client_secret','');
INSERT INTO login_settings VALUES('api_key','');
INSERT INTO login_settings VALUES('enable_facebook','false');
INSERT INTO login_settings VALUES('fb_appid','');
INSERT INTO login_settings VALUES('fb_appsecret','');
INSERT INTO login_settings VALUES('enable_twitter','false');
INSERT INTO login_settings VALUES('consumer_key','');
INSERT INTO login_settings VALUES('consumer_secret','');
INSERT INTO login_settings VALUES('paypal_email','');
INSERT INTO login_settings VALUES('enable_paypal','false');
INSERT INTO login_settings VALUES('paypal_currency','EUR');
INSERT INTO login_settings VALUES('paypal_cost','0.00');
INSERT INTO login_settings VALUES('enable_stripe','false');
INSERT INTO login_settings VALUES('stripe_key','');
INSERT INTO login_settings VALUES('stripe_currency','EUR');
INSERT INTO login_settings VALUES('stripe_cost','0.00');




DROP TABLE IF EXISTS login_users;

CREATE TABLE `login_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `avatar` text NOT NULL,
  `password` text NOT NULL,
  `registered_on` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  `last_active` int(11) NOT NULL,
  `last_action` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  `permission` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `activate_code` text NOT NULL,
  `paypal` text NOT NULL,
  `banned` tinyint(1) NOT NULL,
  `type` text NOT NULL,
  `sid` text NOT NULL,
  `country` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO login_users VALUES('1','admin','admin@admin.nl','','GPVGgPx0UxZS+e1MBDC5qdIrGYtAvdMRfV4b45sdyE6y6jRJNlBd8blH1I3fyduLFtpXyXSQd1tU8QVBRFp0vMOC8b6aeha/KMALjP9H9QAd2u/Ijd9fVxAHwfowWYeCg8EAvYTcu8rUFKWhka3P4DKImbOo33qRjoiUuCF63o8=','0','0','0','','','1','1','c6cd9e1980989b23b86f12e7b7e93ace','','','website','','');