import csv
import requests
import json
import datetime

import xlrd
from xlutils.copy import copy


headers = {
    'Origin': 'https://tools.usps.com',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': 'https://tools.usps.com/zip-code-lookup.htm?byaddress',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
}

file_location = "input.xlsx"
workbook = xlrd.open_workbook(file_location)
clone_workbook = copy(workbook)
clone_sheet = clone_workbook.get_sheet(0)

sheet = workbook.sheet_by_index(0)
i = -1 
for row in range(sheet.nrows):
	i = i + 1
	if i == 0: 
		continue

	effective_date = sheet.cell_value(row, 3)
	time_tuple = xlrd.xldate_as_tuple(effective_date, 0)

	no = sheet.cell_value(row, 0)
	case_no = sheet.cell_value(row, 1)
	order_no = sheet.cell_value(row, 2)
	try:
		address = str(int(sheet.cell_value(row, 4))) + " " + str(sheet.cell_value(row, 5)) + " " + str(sheet.cell_value(row, 6)) + " " + str(sheet.cell_value(row, 7))
	except:
		address = str(sheet.cell_value(row, 4)) + " " + str(sheet.cell_value(row, 5)) + " " + str(sheet.cell_value(row, 6)) + " " + str(sheet.cell_value(row, 7))
	order_type = sheet.cell_value(row, 8)
	violation_description = sheet.cell_value(row, 9)

	data = [
	  # ('companyName', ''),
	  ('address1', address),
	  # ('address2', address2),
	  ('city', 'Los Angeles'),
	  ('state', 'CA'),
	  # ('zip', ''),
	]
	response = requests.post('https://tools.usps.com/tools/app/ziplookup/zipByAddress', headers=headers, data=data)	
	d = json.loads(response.text)
	if d['resultStatus'] == "SUCCESS":
		zip_code = d['addressList'][0]['zip5']
	else:
		zip_code = ""
	clone_sheet.write(i,10, zip_code)
	# print('add')
	clone_workbook.save("output.xlsx")
	
exit()








