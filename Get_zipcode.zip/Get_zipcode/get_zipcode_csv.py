import csv
import requests
import json



def wirte_csv(data, csvfile, writer):
	print("add")
	no = data['no']
	case_no = data['case_no']
	order_no = data['order_no']
	effective_date = data['effective_date']
	address = data['address']
	order_type = data['order_type']
	violation_description = data['violation_description']
	zip_code = data['zip']
	row = {'': no, 'CASE_NO': case_no, 'ORDER_NO': order_no, 'EFFECTIVE_DATE': effective_date, 'ADDRESS': address, 'ORDER_TYPE': order_type, 'VIOLATION DESCRIPTION': violation_description, 'Zip': zip_code}
	writer.writerow(row)
	csvfile.flush()


headers = {
    'Origin': 'https://tools.usps.com',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': 'https://tools.usps.com/zip-code-lookup.htm?byaddress',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
}


file1 = open("input.csv", "rb")
reader = csv.reader(file1)
zip_codeList = []
no = 0 
csvfile = "result"
file_name = 'output.csv'
with open(file_name, 'wb')as csvfile:
	fieldnames = ['', 'CASE_NO', 'ORDER_NO', 'EFFECTIVE_DATE', 'ADDRESS', 'ORDER_TYPE', 'VIOLATION DESCRIPTION', 'Zip']
	writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
	writer.writeheader()
	for row in reader:
		# print(row)
		dataDict = {}
		no += 1
		if no == 1:
			continue
		dataDict['no'] = row[0]
		dataDict['case_no'] = row[1]
		dataDict['order_no'] = row[2]
		dataDict['effective_date'] = row[3]
		dataDict['address'] = row[4] + " " + row[5] + " " + row[6] + " " + row[7]
		dataDict['order_type'] = row[8]
		dataDict['violation_description'] = row[9]
		# print(dataDict['address'])
		address = row[4] + " " + row[5] + " " + row[6] + " " + row[7]
		data = [
		  # ('companyName', ''),
		  ('address1', address),
		  # ('address2', address2),
		  ('city', 'Los Angeles'),
		  ('state', 'CA'),
		  # ('zip', ''),
		]
		response = requests.post('https://tools.usps.com/tools/app/ziplookup/zipByAddress', headers=headers, data=data)	
		print(type(response.text))
		d = json.loads(response.text)
		# print(d)
		if d['resultStatus'] == "SUCCESS":
			zip_code = d['addressList'][0]['zip5']
		else:
			zip_code = ""
		dataDict['zip'] = zip_code
		wirte_csv(dataDict, csvfile, writer)









