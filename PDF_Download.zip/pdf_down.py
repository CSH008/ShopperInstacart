from lxml import html
import urllib
import requests 
import urllib2
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import unicodecsv as csv
import argparse

from lxml import etree
import time
import datetime
import configparser
from os import system

import os

curtime = time.strftime("%Y-%m-%d") + " " + time.strftime("%H:%M:%S")

fn = "config.txt"
config = configparser.ConfigParser()
config.read(fn)
try:
    AllPage = config['DEFAULT']['AllPage'].strip()
except KeyError:
    AllPage = ""

try:
    PageNoStr = config['DEFAULT']['PageNoList'].strip()
    PageNoList = PageNoStr.split(', ')
except KeyError:
    PageNoList = []

# if AllPage == 'true':


Start_url = 'https://hcidapp.lacity.org/CPRA/Home/PublicAccess?id=MTg4NDY='

response = requests.get(Start_url)
response_text = response.text
parser = html.fromstring(response_text)
file_rows = parser.xpath("//div[@class='panel-body']//ul")[0]

print(file_rows)
if AllPage == 'true':

    _pageNo = 0
    for row in file_rows:
        
        tmp = row.xpath('.//a')[0].get('href')
        start = tmp.find('(')
        end = tmp.find(')')
        fileIdx = tmp[start+2: end-1]
        # print(fileIdx)
        download_url = 'https://hcidapp.lacity.org/CPRA/Home/GetContent?unid='+fileIdx
        print(download_url)
        file_name = "DRC Code Enforcement (Pages "+str(_pageNo *100+1) + " - " + str(int(_pageNo*100)+100)+ ").pdf"
        r = urllib2.urlopen(download_url)
        with open(os.path.join('./HCIDLA',file_name), 'wb') as output:
            print(file_name + ' downloading...')
            output.write(r.read())
        
        print(file_name + ' completed')
        _pageNo = _pageNo + 1
    print("all completed")
else:
    for pageNo in PageNoList:
        pageIndex = int(pageNo)//100
        tmp = file_rows[pageIndex].xpath('.//a')[0].get('href')
        start = tmp.find('(')
        end = tmp.find(')')
        fileIdx = tmp[start+2: end-1]
        download_url = 'https://hcidapp.lacity.org/CPRA/Home/GetContent?unid='+fileIdx
        print(download_url)
        file_name = "DRC Code Enforcement (Pages "+str(pageNo) + " - " + str(int(pageNo)+99)+ ").pdf"
        r = urllib2.urlopen(download_url)
        with open(os.path.join('./HCIDLA',file_name), 'wb') as output:
            print(file_name + ' downloading...')
            output.write(r.read())
        
        print(file_name + ' completed')
    print("all completed")


