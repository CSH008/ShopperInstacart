import re
import csv
import requests
import json
import configparser
import time

headers = {
    'Origin': 'https://tools.usps.com',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': 'https://tools.usps.com/zip-code-lookup.htm?byaddress',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
}

def wirte_csv(data, index, unapproved):
	print(index)
	no = index
	name = 'Illegal Unit Tenant'
	address1 = data['address1']
	address2 = data['address2']
	city = 'Los Angeles'
	state = 'CA'
	zip_code = data['zip']
	unapproved = unapproved
	row = {'Sr. No': no, 'Name': name, 'Address 1': address1, 'Apartment No.': address2, 'City': city, 'State': state, 'Zip': zip_code, 'Unapproved': unapproved}
	writer.writerow(row)
	csvfile.flush()

fn = "config.txt"
config = configparser.ConfigParser()
config.read(fn)

Selector = config['DEFAULT']['Selector'].strip()
SelectorList = Selector.split(', ')


f = open("Output.txt", 'r')
lines = f.readlines()
f.close()

num_lines = sum(1 for line in open('Output.txt'))
# print(num_lines)
isStartParse = False
dataList = []

csvfile = "result"
dt = time.strftime("%Y-%m-%d")
# file_name = 'result.csv'
file_name = ( "Illegal Units (" +str(dt) + ").csv").encode('utf-8')
index = 0
with open(file_name, 'wb')as csvfile:
	fieldnames = ['Sr. No', 'Name', 'Address 1', 'Apartment No.', 'City', 'State', 'Zip', 'Unapproved']
	writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
	writer.writeheader()


	for item in SelectorList:
		item = str(item)
		for iLine in range(num_lines):
			lineVal = lines[iLine].strip()

			if lineVal == item:
				isStartParse = True

			if (isStartParse == True) and (lineVal != item) and (lineVal != "BEDROOM1") and (lineVal != "BEDROOM2") and (lineVal != "BEDROOM 3") and (lineVal != "ENTIRE UNIT") and (lineVal != 'BALCONY/DECK') and (lineVal != "COUNTER/DRAINBOARD") and (lineVal != "WINDOW/DOOR MAINT") and (lineVal != "FIXTURE DEF/LEAK") and (lineVal != "SECURE/CLEAN") and (lineVal != "EXIT DOORS/WAYS") and (lineVal != "BALCONY/DECK") and (lineVal != "W/H STRAP/SECURE") and (lineVal != "RECEPTACLES WITHIN 6 FEET") and (lineVal != "HAND/GUARDRAILS") and (lineVal != "RECEPTACLE N/G") and (lineVal != "STAIR/WALK/DECK") and (lineVal != "NEW C/O REQUIRED"):
				if  re.search(r'^[A-Z\s]+$', lineVal) :
					isStartParse = False
				else:
					if re.search(r'^[A-Z0-9\s\/]+$', lineVal):
						if lineVal not in dataList:
							dataDict = {}
							dataList.append(lineVal)
							address1 = lineVal
							address2= ''
							m = re.search(r'(.*?) (AVE|ST|DR|WALK|BLVD) (.*?)\Z', lineVal)
							if m:
								address2 = m.group(3)
								address1 = lineVal[:-len(address2)]

							data = [
							  # ('companyName', ''),
							  ('address1', address1),
							  ('address2', address2),
							  ('city', 'Los Angeles'),
							  ('state', 'CA'),
							  # ('zip', ''),
							]
							response = requests.post('https://tools.usps.com/tools/app/ziplookup/zipByAddress', headers=headers, data=data)
							d = json.loads(response.text)
							if d['resultStatus'] == 'SUCCESS':
								index += 1
								zip_code = d['addressList'][0]['zip5']
								print(zip_code)
								dataDict['address1'] = address1
								dataDict['address2'] = address2
								dataDict['zip'] = zip_code
								unapproved = item
								wirte_csv(dataDict, index, unapproved)
							else:
								continue
						