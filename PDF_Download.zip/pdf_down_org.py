from lxml import html
import urllib
import requests 
import urllib2
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import unicodecsv as csv
import argparse
import re
from lxml import etree
import time
import datetime
import configparser
from os import system
import os


def createFolder(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError:
        print ('Error: Creating directory. ' +  directory)



fn = "config_org.txt"
config = configparser.ConfigParser()
config.read(fn)

Email = config['DEFAULT']['Email'].strip()
Password = config['DEFAULT']['Password'].strip()

Selector = config['DEFAULT']['Selector'].strip()
if Selector == 'all':
    SelectorList = 'all'
else:
    SelectorList = Selector.split(', ')


Login_url = 'https://hcidapp.lacity.org/CPRA/Account/Login'
Base_url = 'https://hcidapp.lacity.org/CPRA/Home'


client = requests.session()
client.get(Login_url, verify=False)

token = client.cookies['__RequestVerificationToken_L0NQUkE1']


cookies = {
    '__RequestVerificationToken_L0NQUkE1': token,
}

headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
}

response = requests.get('https://hcidapp.lacity.org/CPRA/Account/Login', headers=headers, cookies=cookies)

response_text = response.text
parser = html.fromstring(response_text)
__RequestVerificationToken = parser.xpath("//input[@name='__RequestVerificationToken']")[0].get('value')


cookies = {
    '__RequestVerificationToken_L0NQUkE1': token,
}

headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Origin': 'https://hcidapp.lacity.org',
    'Upgrade-Insecure-Requests': '1',
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Referer': 'https://hcidapp.lacity.org/CPRA/Account/Login',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
}

data = [
  ('__RequestVerificationToken', __RequestVerificationToken),
  ('UserName', 'lawyer@downtownlawyer.net'),
  ('Password', 'laws1969'),
  ('RememberMe', 'false'),
]

response = requests.post('https://hcidapp.lacity.org/CPRA/Account/Login', headers=headers, cookies=cookies, data=data,allow_redirects=False)

# print(len(response.cookies))
ASPXCPRAAUTHENTICATE = ''
if response.status_code == 302:
    jar = response.cookies
    redirect_URL2 = 'https://hcidapp.lacity.org/CPRA/Home/PublicAccess'
    ASPXCPRAAUTHENTICATE = response.headers['Set-Cookie']
    response2 = requests.get(redirect_URL2, cookies=jar)

response_text = response2.text

parser = html.fromstring(response_text)

rows = parser.xpath("//select[@id='otherFN']")[0]
allFileDict = {}
for row in rows:
	allFileDict.update({row.text.strip():row.get('value')})
del allFileDict['[Select One]']


if SelectorList == 'all':
    selectIdList = allFileDict.values()
else:
    selectIdList = [allFileDict[x] for x in SelectorList]        
# print(response_text)
# print(allFileDict)
# exit()
# print(selectIdList)
# print(allFileDict)
# exit()
# print(selectIdList)
# exit()
for idx in selectIdList:
    params = (
        ('id', idx),
    )
    value = allFileDict.keys()[allFileDict.values().index(idx)]
    response = requests.get('https://hcidapp.lacity.org/CPRA/Home/PublicAccess', params=params, headers=headers, cookies=cookies)
    response_text = response.text
    parser = html.fromstring(response_text)
    file_rows = parser.xpath("//div[@class='panel-body']//ul")
    for rows in file_rows:
        createFolder('./HCIDLA/'+str(value)+'/')
        for row in rows:
            tmp = row.xpath('.//a')[0].get('href')
            print(row.xpath('.//a')[0].text.strip())
            _file_name = (row.xpath('.//a')[0].text.strip()).replace("#", "")
            _file_name = _file_name.replace(":", "")
            start = tmp.find('(')
            end = tmp.find(')')
            fileIdx = tmp[start+2: end-1]
            download_url = 'https://hcidapp.lacity.org/CPRA/Home/GetContent?unid='+fileIdx
            # file_name = "DRC Code Enforcement (Pages "+str(_pageNo *100+1) + " - " + str(int(_pageNo*100)+100)+ ").pdf"
            r = urllib2.urlopen(download_url)
            with open(os.path.join('./HCIDLA/'+str(value)+'/', _file_name+'.pdf'), 'wb') as output:
                print(_file_name + ' downloading...')
                output.write(r.read())
        
            print(_file_name + ' completed')
        print(len(rows))
        
		# print(row[1].xpath('.//a')[0].get('href'))
    print('\n')
